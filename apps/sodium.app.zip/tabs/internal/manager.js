const internal_pages = {
   newtab: "../newtab.html",
}
